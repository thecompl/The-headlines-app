//* <---Model class to decrease the number of variable passed in constructors -->
