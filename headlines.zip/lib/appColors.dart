import 'package:flutter/material.dart';

Color appMainColor = Color(0xffff914d);
